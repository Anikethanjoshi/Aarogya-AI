export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phoneNumber?: string;
  profileImage?: string;
  preferences: UserPreferences;
  createdAt: Date;
  lastLogin: Date;
}

export type UserRole = 'doctor' | 'pharmacist' | 'medicist' | 'user';

export interface UserPreferences {
  language: Language;
  notifications: boolean;
  darkMode: boolean;
}

export type Language = 'en' | 'hi';

export interface HealthSession {
  id: string;
  userId: string;
  type: 'consultation' | 'checkup' | 'emergency' | 'mental_health';
  status: 'active' | 'completed' | 'scheduled';
  startTime: Date;
  endTime?: Date;
  notes?: string;
  aiAgentId?: string;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: 'basic' | 'premium' | 'professional';
  status: 'active' | 'inactive' | 'expired';
  startDate: Date;
  endDate: Date;
  features: string[];
}

export interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, userData: Partial<User>) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
}