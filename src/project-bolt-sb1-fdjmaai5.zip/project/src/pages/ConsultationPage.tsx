import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Phone, 
  Settings,
  MessageCircle,
  Activity,
  Heart,
  Clock
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/UI/Button';
import { LoadingSpinner } from '../components/UI/LoadingSpinner';

export const ConsultationPage: React.FC = () => {
  const { t } = useLanguage();
  const [isLoading, setIsLoading] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [sessionTime, setSessionTime] = useState(0);
  const [sessionStatus, setSessionStatus] = useState<'connecting' | 'connected' | 'ended'>('connecting');

  useEffect(() => {
    // Simulate loading and connection
    const timer = setTimeout(() => {
      setIsLoading(false);
      setSessionStatus('connected');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionStatus === 'connected') {
      interval = setInterval(() => {
        setSessionTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionStatus]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setSessionStatus('ended');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-saffron-50 to-emerald-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <LoadingSpinner size="lg" text={t('consultation.loading')} />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-8 max-w-md"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {t('consultation.title')}
            </h2>
            <p className="text-gray-600 text-sm">
              {t('consultation.subtitle')}
            </p>
          </motion.div>
        </motion.div>
      </div>
    );
  }

  if (sessionStatus === 'ended') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-saffron-50 to-emerald-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 text-center"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-emerald-400 to-green-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Session Complete</h2>
          <p className="text-gray-600 mb-6">
            Your consultation session has ended. Session duration: {formatTime(sessionTime)}
          </p>
          <div className="space-y-3">
            <Button className="w-full">Download Session Summary</Button>
            <Button variant="outline" className="w-full">Schedule Follow-up</Button>
            <Button variant="ghost" className="w-full" onClick={() => window.history.back()}>
              Back to Dashboard
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-white font-medium">Live Session</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <Clock className="h-4 w-4" />
                <span className="font-mono">{formatTime(sessionTime)}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-gray-300">
                <Activity className="h-4 w-4" />
                <span className="text-sm">AI Health Assistant</span>
              </div>
              <Button variant="ghost" size="sm" icon={Settings} className="text-gray-300 hover:text-white">
                Settings
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Video Area */}
      <div className="flex-1 flex">
        {/* AI Video Feed */}
        <div className="flex-1 relative bg-gray-800">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative h-full flex items-center justify-center"
          >
            {/* Tavus AI Video Agent Placeholder */}
            <div className="w-full h-full bg-gradient-to-br from-saffron-500/20 to-emerald-500/20 relative overflow-hidden">
              {/* This would be replaced with actual Tavus iframe */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-32 h-32 bg-gradient-to-r from-saffron-400 to-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="h-16 w-16 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Dr. Aarogya AI</h3>
                  <p className="text-gray-300">Your Virtual Health Companion</p>
                  <div className="mt-4 text-sm text-gray-400">
                    Speaking in: English • हिंदी
                  </div>
                </div>
              </div>
              
              {/* Tavus Integration Placeholder */}
              <div className="absolute bottom-4 left-4 bg-black/50 rounded-lg p-2 text-white text-xs">
                Tavus AI Video Agent
              </div>
            </div>

            {/* User Video (Self View) */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute top-4 right-4 w-48 h-36 bg-gray-700 rounded-lg overflow-hidden border-2 border-gray-600"
            >
              {isVideoOn ? (
                <div className="w-full h-full bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center">
                  <span className="text-gray-300 text-sm">Your Video</span>
                </div>
              ) : (
                <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                  <VideoOff className="h-8 w-8 text-gray-500" />
                </div>
              )}
            </motion.div>
          </motion.div>
        </div>

        {/* Chat Sidebar */}
        <motion.div
          initial={{ x: 300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="w-80 bg-white border-l border-gray-200 flex flex-col"
        >
          {/* Chat Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-saffron-600" />
              <h3 className="font-semibold text-gray-900">Session Chat</h3>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            <div className="space-y-3">
              <div className="bg-saffron-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <Heart className="h-4 w-4 text-saffron-600" />
                  <span className="text-sm font-medium text-saffron-800">Dr. Aarogya AI</span>
                </div>
                <p className="text-sm text-saffron-700">
                  Namaste! Welcome to your health consultation. How are you feeling today?
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-3 ml-8">
                <div className="flex items-center space-x-2 mb-1">
                  <div className="w-4 h-4 bg-emerald-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-800">You</span>
                </div>
                <p className="text-sm text-gray-700">
                  Hello! I've been having some headaches lately.
                </p>
              </div>

              <div className="bg-saffron-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <Heart className="h-4 w-4 text-saffron-600" />
                  <span className="text-sm font-medium text-saffron-800">Dr. Aarogya AI</span>
                </div>
                <p className="text-sm text-saffron-700">
                  I understand. Can you tell me more about when these headaches occur and their intensity?
                </p>
              </div>
            </div>
          </div>

          {/* Chat Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-saffron-500 focus:border-transparent"
              />
              <Button size="sm" className="px-3">
                Send
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Control Bar */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="bg-gray-800 border-t border-gray-700"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-20">
            <div className="flex items-center space-x-4">
              {/* Microphone Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsAudioOn(!isAudioOn)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isAudioOn
                    ? 'bg-gray-600 hover:bg-gray-700 text-white'
                    : 'bg-red-500 hover:bg-red-600 text-white'
                }`}
              >
                {isAudioOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              </motion.button>

              {/* Video Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsVideoOn(!isVideoOn)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isVideoOn
                    ? 'bg-gray-600 hover:bg-gray-700 text-white'
                    : 'bg-red-500 hover:bg-red-600 text-white'
                }`}
              >
                {isVideoOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
              </motion.button>

              {/* End Call */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleEndCall}
                className="w-12 h-12 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center text-white transition-colors"
              >
                <Phone className="h-5 w-5 rotate-[135deg]" />
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};