import React from 'react';
import { motion } from 'framer-motion';
import { 
  Video, 
  Calendar, 
  Activity, 
  Heart, 
  AlertTriangle, 
  Clock,
  Users,
  TrendingUp,
  MessageCircle,
  Shield
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/UI/Button';
import { Link } from 'react-router-dom';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();

  const quickActions = [
    {
      icon: Video,
      title: t('dashboard.start_consultation'),
      description: 'Start a face-to-face AI consultation',
      color: 'from-saffron-500 to-orange-500',
      link: '/consultation',
    },
    {
      icon: Calendar,
      title: 'Schedule Appointment',
      description: 'Book a session with healthcare professionals',
      color: 'from-emerald-500 to-green-500',
      link: '/appointments',
    },
    {
      icon: Activity,
      title: 'Health Check-up',
      description: 'Quick health assessment and recommendations',
      color: 'from-blue-500 to-indigo-500',
      link: '/checkup',
    },
    {
      icon: AlertTriangle,
      title: t('dashboard.emergency'),
      description: 'Immediate medical assistance',
      color: 'from-red-500 to-pink-500',
      link: '/emergency',
    },
  ];

  const healthStats = [
    {
      icon: Heart,
      label: 'Health Score',
      value: '94%',
      change: '+2%',
      color: 'text-saffron-600',
    },
    {
      icon: Activity,
      label: 'Sessions This Month',
      value: '12',
      change: '+4',
      color: 'text-emerald-600',
    },
    {
      icon: Clock,
      label: 'Avg Session Time',
      value: '15 min',
      change: '-2 min',
      color: 'text-blue-600',
    },
    {
      icon: TrendingUp,
      label: 'Improvement',
      value: '18%',
      change: '+5%',
      color: 'text-purple-600',
    },
  ];

  const recentSessions = [
    {
      id: 1,
      type: 'General Consultation',
      date: '2 hours ago',
      status: 'Completed',
      duration: '12 min',
    },
    {
      id: 2,
      type: 'Mental Health Check',
      date: '1 day ago',
      status: 'Completed',
      duration: '18 min',
    },
    {
      id: 3,
      type: 'Prescription Review',
      date: '3 days ago',
      status: 'Completed',
      duration: '8 min',
    },
  ];

  const healthTips = [
    {
      title: 'Stay Hydrated',
      description: 'Drink at least 8 glasses of water daily for optimal health.',
      icon: '💧',
    },
    {
      title: 'Regular Exercise',
      description: '30 minutes of daily physical activity boosts immunity.',
      icon: '🏃‍♂️',
    },
    {
      title: 'Balanced Diet',
      description: 'Include fruits, vegetables, and whole grains in your meals.',
      icon: '🥗',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-saffron-50/30 to-emerald-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                  {t('dashboard.welcome')}, {user?.name}!
                </h1>
                <p className="text-gray-600 mt-1">
                  {t('dashboard.title')} • {new Date().toLocaleDateString('en-IN', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
                <div className="flex items-center mt-2 space-x-4">
                  <div className="flex items-center space-x-2 text-sm text-emerald-600">
                    <Shield className="h-4 w-4" />
                    <span>Verified {user?.role}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-saffron-600">
                    <Heart className="h-4 w-4" />
                    <span>Premium Member</span>
                  </div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="w-16 h-16 bg-gradient-to-r from-saffron-400 to-emerald-400 rounded-full flex items-center justify-center">
                  <Users className="h-8 w-8 text-white" />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {quickActions.map((action, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.1 + index * 0.05 }}
                    whileHover={{ scale: 1.02 }}
                    className="group"
                  >
                    <Link to={action.link}>
                      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${action.color} p-3 mb-4 group-hover:scale-110 transition-transform`}>
                          <action.icon className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="font-semibold text-gray-900 mb-2">{action.title}</h3>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </motion.section>

            {/* Health Stats */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Health Overview</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {healthStats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + index * 0.05 }}
                    className="bg-white p-4 rounded-xl shadow-lg border border-gray-100"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <stat.icon className={`h-5 w-5 ${stat.color}`} />
                      <span className="text-xs text-green-600 font-medium">{stat.change}</span>
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.section>

            {/* Recent Sessions */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">{t('dashboard.recent_sessions')}</h2>
                <Link to="/consultations" className="text-saffron-600 hover:text-saffron-700 text-sm font-medium">
                  View All
                </Link>
              </div>
              <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
                {recentSessions.map((session, index) => (
                  <div key={session.id} className={`p-4 ${index !== recentSessions.length - 1 ? 'border-b border-gray-100' : ''}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-saffron-100 to-emerald-100 rounded-full flex items-center justify-center">
                          <MessageCircle className="h-5 w-5 text-saffron-600" />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{session.type}</div>
                          <div className="text-sm text-gray-500">{session.date} • {session.duration}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {session.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* AI Consultation Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-gradient-to-r from-saffron-500 to-emerald-500 p-6 rounded-xl text-white"
            >
              <div className="flex items-center mb-4">
                <Video className="h-8 w-8 mr-3" />
                <div>
                  <h3 className="font-semibold">AI Video Consultation</h3>
                  <p className="text-sm opacity-90">Face-to-face with AI doctor</p>
                </div>
              </div>
              <p className="text-sm mb-4 opacity-90">
                Get instant medical advice through our advanced AI-powered video consultation system.
              </p>
              <Link to="/consultation">
                <Button 
                  variant="secondary" 
                  className="w-full bg-white text-saffron-600 hover:bg-gray-100"
                  icon={Video}
                >
                  Start Now
                </Button>
              </Link>
            </motion.div>

            {/* Health Tips */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl shadow-lg border border-gray-100 p-6"
            >
              <h3 className="font-semibold text-gray-900 mb-4">{t('dashboard.health_tips')}</h3>
              <div className="space-y-4">
                {healthTips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <span className="text-2xl">{tip.icon}</span>
                    <div>
                      <h4 className="font-medium text-gray-900 text-sm">{tip.title}</h4>
                      <p className="text-xs text-gray-600 mt-1">{tip.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Emergency Support */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-red-50 border border-red-200 rounded-xl p-6"
            >
              <div className="flex items-center mb-3">
                <AlertTriangle className="h-6 w-6 text-red-600 mr-2" />
                <h3 className="font-semibold text-red-900">Emergency Support</h3>
              </div>
              <p className="text-sm text-red-700 mb-4">
                Need immediate medical assistance? Our emergency AI is available 24/7.
              </p>
              <Button 
                variant="outline" 
                className="w-full border-red-300 text-red-600 hover:bg-red-50"
                icon={AlertTriangle}
              >
                Emergency Chat
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};