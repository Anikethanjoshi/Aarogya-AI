import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Heart, 
  Video, 
  Globe, 
  Shield, 
  Clock, 
  Users,
  Stethoscope,
  Brain,
  Pill,
  Activity
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/UI/Button';

export const HomePage: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      icon: Video,
      title: 'Face-to-Face AI Consultation',
      description: 'Real-time video interaction with AI health agents',
      color: 'from-saffron-500 to-orange-500'
    },
    {
      icon: Globe,
      title: 'Multilingual Support',
      description: 'Available in English, Hindi, and Sanskrit',
      color: 'from-emerald-500 to-green-500'
    },
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Healthcare support anytime, anywhere',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your health data is protected',
      color: 'from-purple-500 to-pink-500'
    }
  ];

  const roles = [
    {
      icon: Stethoscope,
      title: 'Doctors',
      description: 'Enhanced patient care with AI assistance',
      users: '10K+ Medical Professionals'
    },
    {
      icon: Pill,
      title: 'Pharmacists',
      description: 'Smart medication management',
      users: '5K+ Pharmacies'
    },
    {
      icon: Brain,
      title: 'Medicists',
      description: 'Advanced diagnostic support',
      users: '2K+ Specialists'
    },
    {
      icon: Users,
      title: 'Patients',
      description: 'Accessible healthcare for all',
      users: '1M+ Happy Users'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-saffron-50 via-white to-emerald-50">
        <div className="absolute inset-0 bg-gradient-to-r from-saffron-100/20 to-emerald-100/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            {/* Sanskrit Invocation */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-6"
            >
              <p className="text-2xl md:text-3xl font-devanagari text-saffron-600 mb-2">
                {t('app.invocation')}
              </p>
              <p className="text-sm text-gray-600 italic">Let us begin health</p>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6"
            >
              <span className="bg-gradient-to-r from-saffron-600 via-emerald-600 to-saffron-600 bg-clip-text text-transparent">
                AarogyaAI
              </span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-xl md:text-2xl text-gray-700 mb-4 max-w-3xl mx-auto"
            >
              {t('app.tagline')}
            </motion.p>

            {/* Hindi Motto */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-lg font-devanagari text-emerald-600 mb-8"
            >
              {t('app.motto')}
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <Link to="/auth">
                <Button size="lg" icon={Video} className="w-full sm:w-auto">
                  Start Free Consultation
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Watch Demo
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="grid grid-cols-3 gap-8 mt-16 max-w-md mx-auto"
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-saffron-600">1M+</div>
                <div className="text-sm text-gray-600">Users Served</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-600">24/7</div>
                <div className="text-sm text-gray-600">Availability</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-lotus-600">3</div>
                <div className="text-sm text-gray-600">Languages</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Revolutionary Healthcare Features
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Experience the future of healthcare with AI-powered consultations designed for Bharat
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.color} p-3 mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Roles Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Built for Every Healthcare Professional
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Tailored experiences for doctors, pharmacists, medicists, and patients
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {roles.map((role, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 text-center border border-gray-100"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-saffron-100 to-emerald-100 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <role.icon className="h-8 w-8 text-saffron-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  For {role.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  {role.description}
                </p>
                <div className="text-xs text-emerald-600 font-medium">
                  {role.users}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-saffron-500 to-emerald-500">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Transform Your Healthcare Experience?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join millions of Indians who trust AarogyaAI for their health and wellness needs
            </p>
            <Link to="/auth">
              <Button
                variant="secondary"
                size="lg"
                icon={Activity}
                className="bg-white text-saffron-600 hover:bg-gray-100"
              >
                Get Started Today
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};