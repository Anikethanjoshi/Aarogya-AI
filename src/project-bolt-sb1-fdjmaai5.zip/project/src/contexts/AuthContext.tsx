import React, { createContext, useContext, useEffect, useState } from 'react';
import { AuthContextType, User, UserRole } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Mock authentication for demo purposes
  useEffect(() => {
    // Simulate loading and check for existing session
    const timer = setTimeout(() => {
      const mockUser: User = {
        id: '1',
        email: 'demo@aarogyaai.com',
        name: 'Dr. Demo User',
        role: 'doctor' as UserRole,
        preferences: {
          language: 'en',
          notifications: true,
          darkMode: false,
        },
        createdAt: new Date(),
        lastLogin: new Date(),
      };
      setUser(mockUser);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const signIn = async (email: string, password: string) => {
    setLoading(true);
    // Mock sign in - replace with Firebase auth
    await new Promise(resolve => setTimeout(resolve, 1000));
    const mockUser: User = {
      id: '1',
      email,
      name: 'Demo User',
      role: 'user' as UserRole,
      preferences: {
        language: 'en',
        notifications: true,
        darkMode: false,
      },
      createdAt: new Date(),
      lastLogin: new Date(),
    };
    setUser(mockUser);
    setLoading(false);
  };

  const signUp = async (email: string, password: string, userData: Partial<User>) => {
    setLoading(true);
    // Mock sign up - replace with Firebase auth
    await new Promise(resolve => setTimeout(resolve, 1000));
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name: userData.name || 'New User',
      role: userData.role || 'user',
      preferences: {
        language: 'en',
        notifications: true,
        darkMode: false,
      },
      createdAt: new Date(),
      lastLogin: new Date(),
    };
    setUser(mockUser);
    setLoading(false);
  };

  const signOut = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    setUser(null);
    setLoading(false);
  };

  const updateProfile = async (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};