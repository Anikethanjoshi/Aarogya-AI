import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

const translations = {
  en: {
    // Common
    'app.name': 'AarogyaAI',
    'app.tagline': 'Let good health be accessible to all',
    'app.invocation': 'आरोग्यम् आरभामहे', // Sanskrit: Let us begin health
    'app.motto': 'आरोग्य हर जन तक पहुँचे', // Hindi: Let health reach everyone
    
    // Navigation
    'nav.home': 'Home',
    'nav.dashboard': 'Dashboard',
    'nav.consultations': 'Consultations',
    'nav.profile': 'Profile',
    'nav.settings': 'Settings',
    'nav.logout': 'Logout',
    
    // Authentication
    'auth.signin': 'Sign In',
    'auth.signup': 'Sign Up',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.name': 'Full Name',
    'auth.role': 'Role',
    'auth.welcome': 'Welcome to AarogyaAI',
    'auth.subtitle': 'Your virtual health companion',
    
    // Roles
    'role.doctor': 'Doctor',
    'role.pharmacist': 'Pharmacist',
    'role.medicist': 'Medicist',
    'role.user': 'Patient',
    
    // Dashboard
    'dashboard.title': 'Health Dashboard',
    'dashboard.welcome': 'Welcome back',
    'dashboard.start_consultation': 'Start AI Consultation',
    'dashboard.recent_sessions': 'Recent Sessions',
    'dashboard.health_tips': 'Health Tips',
    'dashboard.emergency': 'Emergency Support',
    
    // Consultation
    'consultation.title': 'AI Health Consultation',
    'consultation.subtitle': 'Face-to-face conversation with your AI health companion',
    'consultation.start': 'Start Video Session',
    'consultation.loading': 'Preparing your consultation...',
    
    // Common Actions
    'action.save': 'Save',
    'action.cancel': 'Cancel',
    'action.continue': 'Continue',
    'action.back': 'Back',
    'action.next': 'Next',
    'action.submit': 'Submit',
    
    // Status
    'status.loading': 'Loading...',
    'status.error': 'Something went wrong',
    'status.success': 'Success!',
  },
  hi: {
    // Common
    'app.name': 'आरोग्यAI',
    'app.tagline': 'अच्छा स्वास्थ्य सभी के लिए सुलभ हो',
    'app.invocation': 'आरोग्यम् आरभामहे',
    'app.motto': 'आरोग्य हर जन तक पहुँचे',
    
    // Navigation
    'nav.home': 'होम',
    'nav.dashboard': 'डैशबोर्ड',
    'nav.consultations': 'परामर्श',
    'nav.profile': 'प्रोफाइल',
    'nav.settings': 'सेटिंग्स',
    'nav.logout': 'लॉगआउट',
    
    // Authentication
    'auth.signin': 'साइन इन',
    'auth.signup': 'साइन अप',
    'auth.email': 'ईमेल',
    'auth.password': 'पासवर्ड',
    'auth.name': 'पूरा नाम',
    'auth.role': 'भूमिका',
    'auth.welcome': 'आरोग्यAI में आपका स्वागत है',
    'auth.subtitle': 'आपका वर्चुअल स्वास्थ्य साथी',
    
    // Roles
    'role.doctor': 'डॉक्टर',
    'role.pharmacist': 'फार्मासिस्ट',
    'role.medicist': 'मेडिसिस्ट',
    'role.user': 'मरीज़',
    
    // Dashboard
    'dashboard.title': 'स्वास्थ्य डैशबोर्ड',
    'dashboard.welcome': 'वापस आपका स्वागत है',
    'dashboard.start_consultation': 'AI परामर्श शुरू करें',
    'dashboard.recent_sessions': 'हाल के सत्र',
    'dashboard.health_tips': 'स्वास्थ्य सुझाव',
    'dashboard.emergency': 'आपातकालीन सहायता',
    
    // Consultation
    'consultation.title': 'AI स्वास्थ्य परामर्श',
    'consultation.subtitle': 'अपने AI स्वास्थ्य साथी के साथ आमने-सामने बातचीत',
    'consultation.start': 'वीडियो सत्र शुरू करें',
    'consultation.loading': 'आपका परामर्श तैयार हो रहा है...',
    
    // Common Actions
    'action.save': 'सेव करें',
    'action.cancel': 'रद्द करें',
    'action.continue': 'जारी रखें',
    'action.back': 'वापस',
    'action.next': 'अगला',
    'action.submit': 'सबमिट करें',
    
    // Status
    'status.loading': 'लोड हो रहा है...',
    'status.error': 'कुछ गलत हुआ',
    'status.success': 'सफल!',
  },
};

interface LanguageProviderProps {
  children: React.ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('aarogyaai-language') as Language;
    if (savedLanguage && ['en', 'hi'].includes(savedLanguage)) {
      setLanguage(savedLanguage);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('aarogyaai-language', lang);
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage: handleSetLanguage,
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};