import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Globe, LogOut, Settings, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { motion } from 'framer-motion';

export const Header: React.FC = () => {
  const { user, signOut } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  const handleLanguageToggle = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-white/95 backdrop-blur-sm border-b border-emerald-100 sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <Heart className="h-8 w-8 text-saffron-500 group-hover:text-saffron-600 transition-colors" />
              <div className="absolute inset-0 bg-gradient-to-r from-saffron-400 to-emerald-400 opacity-20 rounded-full blur-sm group-hover:opacity-30 transition-opacity"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold bg-gradient-to-r from-saffron-600 to-emerald-600 bg-clip-text text-transparent">
                {t('app.name')}
              </span>
              <span className="text-xs text-gray-500 hidden sm:block font-devanagari">
                {t('app.invocation')}
              </span>
            </div>
          </Link>

          {/* Navigation */}
          {user && (
            <nav className="hidden md:flex items-center space-x-8">
              <Link
                to="/dashboard"
                className="text-gray-700 hover:text-saffron-600 font-medium transition-colors"
              >
                {t('nav.dashboard')}
              </Link>
              <Link
                to="/consultations"
                className="text-gray-700 hover:text-saffron-600 font-medium transition-colors"
              >
                {t('nav.consultations')}
              </Link>
            </nav>
          )}

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Language Toggle */}
            <button
              onClick={handleLanguageToggle}
              className="flex items-center space-x-1 px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors group"
              title="Toggle Language"
            >
              <Globe className="h-4 w-4 text-gray-600 group-hover:text-saffron-600 transition-colors" />
              <span className="text-sm font-medium text-gray-700 group-hover:text-saffron-600 transition-colors">
                {language.toUpperCase()}
              </span>
            </button>

            {user ? (
              <div className="flex items-center space-x-3">
                {/* Profile */}
                <Link
                  to="/profile"
                  className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors group"
                >
                  <div className="w-8 h-8 bg-gradient-to-r from-saffron-400 to-emerald-400 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                  <div className="hidden sm:block">
                    <p className="text-sm font-medium text-gray-700 group-hover:text-saffron-600 transition-colors">
                      {user.name}
                    </p>
                    <p className="text-xs text-gray-500 capitalize">
                      {t(`role.${user.role}`)}
                    </p>
                  </div>
                </Link>

                {/* Settings */}
                <Link
                  to="/settings"
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors group"
                  title={t('nav.settings')}
                >
                  <Settings className="h-5 w-5 text-gray-600 group-hover:text-saffron-600 transition-colors" />
                </Link>

                {/* Logout */}
                <button
                  onClick={signOut}
                  className="p-2 rounded-lg hover:bg-red-50 transition-colors group"
                  title={t('nav.logout')}
                >
                  <LogOut className="h-5 w-5 text-gray-600 group-hover:text-red-600 transition-colors" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link
                  to="/auth"
                  className="px-4 py-2 text-saffron-600 hover:text-saffron-700 font-medium transition-colors"
                >
                  {t('auth.signin')}
                </Link>
                <Link
                  to="/auth"
                  className="px-4 py-2 bg-gradient-to-r from-saffron-500 to-emerald-500 text-white rounded-lg hover:from-saffron-600 hover:to-emerald-600 font-medium transition-all shadow-md hover:shadow-lg"
                >
                  {t('auth.signup')}
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
};