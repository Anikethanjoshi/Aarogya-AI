import React from 'react';
import { Heart, Globe, Shield, Users } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { motion } from 'framer-motion';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="bg-gradient-to-r from-saffron-50 to-emerald-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <Heart className="h-8 w-8 text-saffron-500" />
              <div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-saffron-600 to-emerald-600 bg-clip-text text-transparent">
                  {t('app.name')}
                </h3>
                <p className="text-sm text-gray-600 font-devanagari">
                  {t('app.motto')}
                </p>
              </div>
            </div>
            <p className="text-gray-600 mb-4 max-w-md">
              {t('app.tagline')}. Empowering Bharat with AI-powered healthcare accessible in your language, anytime, anywhere.
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Globe className="h-4 w-4" />
                <span>Multilingual Support</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Shield className="h-4 w-4" />
                <span>Secure & Private</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-saffron-600 transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">How It Works</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Emergency Support</a></li>
              <li><a href="#" className="hover:text-saffron-600 transition-colors">Feedback</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              © 2025 AarogyaAI. All rights reserved. Built for Bharat with ❤️
            </p>
            <div className="flex items-center space-x-2 mt-4 md:mt-0">
              <Users className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-500">
                Serving millions across India
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.footer>
  );
};